rm -f *.aux *.fdb_latexmk *.fls *.lof *.log *.out *.toc *.synctex.gz *.pdf
